package Pages;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import Base.BaseClass;

public class EnterToDoList extends BaseClass {
	
	public EnterToDoList EnterData() throws InterruptedException 
	{
		WebElement ele = driver.findElement(By.xpath("//input[@type='text']"));
		ele.sendKeys("To Check Emails",Keys.ENTER);		
		ele.sendKeys("To Attend Standup Meeting\",Keys.ENTER");
		ele.sendKeys("Check scripts",Keys.ENTER);
		return this; 	
	}
	
	public EnterToDoList GetDataSize()
	{
		int Size = driver.findElements(By.xpath("//ul[@class='todo-list']//li")).size();
		System.out.println(Size);
		return this;
	}
	
		public EnterToDoList verifyActiveList() 
	{
		String element = driver.findElement(By.xpath("//span[@class='todo-count']")).getText();
		System.out.println("Active elements "+ element);
		return this;
	}
	
	public EnterToDoList ClickAll()
	{
		driver.findElement(By.xpath("//a[text()='All']")).click();	
		return this;
	}
	
	public EnterToDoList ClickCheckbox()
	{
		driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).click();
		return this;
	}

	
	public EnterToDoList VerifyActiveCount() 
	{
		String Completed = driver.findElement(By.xpath("//footer[@class='footer']/span")).getText();
		System.out.println("Active list count after click on complete " + Completed);
		return this;
	}
	
	public EnterToDoList ClickActive()
	{
		driver.findElement(By.xpath("//a[text()='Active']")).click();
		return this;
	}
	
	public EnterToDoList ClickClearCompleted()
	{
		driver.findElement(By.xpath("//button[text()='Clear completed']")).click();
		return this;
	}
	
	public EnterToDoList ClickCompleted()
	{
		driver.findElement(By.xpath("//a[text()='Completed']")).click();
		return this;
	}
	
	


}
