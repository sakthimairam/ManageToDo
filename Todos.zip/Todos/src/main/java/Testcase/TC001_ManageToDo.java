package Testcase;

import org.testng.annotations.Test;

import Base.BaseClass;
import Pages.EnterToDoList;

public class TC001_ManageToDo extends BaseClass{

	@Test
	public void runToDo() throws InterruptedException 
	{
		new EnterToDoList()
		.EnterData()
		.GetDataSize()
		.ClickAll()
		.ClickActive()
		.verifyActiveList()
		.VerifyActiveCount()
		.ClickCheckbox()
		.ClickCompleted()
		.ClickActive()
		.ClickClearCompleted()
		.ClickCompleted()
		.ClickActive()
		.ClickAll();
				
	}
}
